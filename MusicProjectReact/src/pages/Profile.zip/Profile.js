import React, { Component } from 'react';
import Navbar from '../components/CustomNavbar';
import Footer from '../components/Footer';
import Jumbotron from '../components/Jumbotron';

import { Grid, Row, Col,ListGroup, ListGroupItem, Form, Button} from 'react-bootstrap';
import ReactYoutube from '../thirdParty/ReactYoutube';
import axios from 'axios';
import './styles.css';
import Comments from '../components/Comments'


Array.prototype.groupBy = function(prop) {
    return this.reduce(function(groups, item) {
      var val = item[prop]
      groups[val] = groups[val] || []
      groups[val].push(item)
      return groups
    }, {})
  }



  const bgBlue= {
    background: '#1c0e3e',
  };

class Home extends Component {
    constructor(props) {
        super(props);
    
        this.state = {
            user : {
                fname: '',
                lname: '',
                uname: '',
                userid: 0,
                email: ''    
            },
            allSongsList:[],
            allUsersList:[],
            allConcertsList[],
            currentSongId:'',
            currentTrackId: '',
            currentSongName:'',
            currentComments: [],
            songIndex: {}     
        };
    }



    shuffle = (array) => {
        
        var currentIndex = array.length, temporaryValue, randomIndex;
      
        // While there remain elements to shuffle...
        while (0 !== currentIndex) {
      
          // Pick a remaining element...
          randomIndex = Math.floor(Math.random() * currentIndex);
          currentIndex -= 1;
      
          // And swap it with the current element.
          temporaryValue = array[currentIndex];
          array[currentIndex] = array[randomIndex];
          array[randomIndex] = temporaryValue;
        }
        this.setState({ allSongsList: array });
        return array;
    }
    getAllSongs = () => {
        axios.get(`http://localhost:3001/users/allSongs`)
          .then(res => { 
              console.log("2222222222222222222222222222222222")
              console.log(res.data);
              res.data = this.shuffle(res.data);
              var test = res.data[0].URL;
              if (test.includes('v=')) {
                var temp1= res.data[0].URL.split('v=').pop();
                if (temp1.includes('&')){
                    var temp2 = temp1.split('&');
                    temp1 = temp2[0];
                }
                console.log(res.data[0].UserId)
                    this.setState({ currentTrackId: res.data[0].UserId})
                    this.setState({ currentComments: res.data[0].comments})
                    this.setState({ currentSongId: temp1 });
                    this.setState({ currentSongName: res.data[0].SongName})
              } else {
                  var temp3 = test.split('/').pop()
                  this.setState({ currentSongId: temp3 });
                  this.setState({ currentTrackId: res.data[0].UserId})
                  this.setState({ currentComments: res.data[0].comments})
                  this.setState({ currentSongName: res.data[0].SongName})
              } 
              this.setState({ allSongsList: res.data });
          })
    }
    
    getAllUsers = () => {
        axios.get(`http://localhost:3001/users/allusers`)
          .then(res => { 
            console.log(res.data, "-----getAllUsers")
              this.setState({ allUsersList: res.data  });
          })
    }
    
    componentDidMount() {
        var fName=localStorage.getItem('firstName');
        var lName=localStorage.getItem('lastName');
        var uName=localStorage.getItem('userName');
        var userId=localStorage.getItem('userId');
        var email=localStorage.getItem('email');
        
        this.setState({
            user : {
                fname: fName,
                lname: lName,
                uname: uName,
                userid: userId,
                email: email

            }
        })
        this.getAllUsers()
        this.getAllSongs();
        this.getAllConcerts();
    }
    getAllConcerts = () => {
        axios.get(`http://localhost:3001/users/allConcerts`)
        .then(res => { 
          console.log(res.data, "-----getAllConcerts")
            this.setState({ allConcertsList: res.data  });
        })
  }
        // https://api.songkick.com/api/3.0/metro_areas/23068-us-phoenix/calendar.json?apikey={your_api_key}
    }
   stripIt(url){
        if (url.includes('v=')) {
            var temp1= url.split('v=').pop();
            if (temp1.includes('&')){
                var temp2 = temp1.split('&');
                temp1 = temp2[0];
            }
                return temp1
          } else {
              var temp3 = url.split('/').pop()
              return temp3;
          }
    }
    handleSongChange(song){
      console.log(song, '%%%%%%%%%%%%%%%%%%%%%%%%%%%')
       this.setState({currentSongId: this.stripIt(song.URL)});
       this.setState({currentComments: song.comments});
       this.setState({currentSongName: song.SongName});
       this.setState({currentTrackId: song.UserId});

    }

    handleSubmit = event => {
        event.preventDefault();
        
        var songComment= document.getElementById('songComment').value;
        var songId = this.state.currentTrackId;
        var userId = this.state.user.userid;
        console.log(songId)
        var newComment = {
           Comment: songComment,
           TrackId: songId,
           Owner: userId
        }
        console.log(newComment, '------')
        var postURL= 'http://localhost:3001/users/postcomment/';
        axios.post(postURL, {
           Comment: songComment,
           TrackId: songId,
           Owner: userId
        }).then(comments => {
            document.getElementById('songComment').value = '';
            const newArray = [];
          
            console.log('~~~~~~~~~~')
            console.log( comments.data)
            this.setState({currentComments : comments.data})
        })
        
 
      }

    render() {
        
        return (
            <div >
                 <Jumbotron title="Profile" subtitle="User Profile" />
                <Navbar />
                <div className="container"  style={bgBlue}>
                    <h2>Welcome, <span>{this.state.user.uname}</span></h2>
                    <Grid fluid>
                        <Row className="show-grid">
                            <Col sm={12} md={3}  className="col-design">
                                <h2>Users</h2>
                                
                                <ListGroup>
                                  {this.state.allUsersList.map((user, index) => (
                                    <ListGroupItem key={index}>
                                    <Button className="btn-uvideo">
                                      {user.Username}
                                    </Button>
                                      <ListGroup> 
                                        {user.songs.map((song, index) => (
                                          <ListGroupItem key={index}>
                                            <Button 
                                                className="btn-video" 
                                                onClick={( )=>this.handleSongChange(song)}
                                            >
                                              <p>{song.SongName}</p>
                                            </Button>
                                          </ListGroupItem>
                                        ))}
                                      </ListGroup>
                                    </ListGroupItem>
                                  ))}
                                </ListGroup>
                            </Col>
                            <Col sm={12} md={6}>
                                <h2>{this.state.currentSongName}</h2>
                                <ReactYoutube videoId={this.state.currentSongId}/>
                                  <h2>Comments</h2>
                                 <Comments comms={this.state.currentComments}/>
   
                                  <h4>make a comment</h4>
                                  <Form  className="form-container"  horizontal  
                                    onSubmit={this.handleSubmit}> 
                                      <input type="text" id="songComment" placeholder="make a comment" />

                                      <Button 
                                        type="submit" 
                                        id="submitButton"  
                                        className="btnBlue" 
                                        vertical block
                                      >
                                        Submit
                                      </Button>
                                  </Form>    

                               
                            </Col>
                            <Col sm={12} md={3} className="col-design">
                                <h2>Playlist</h2>

                               <ListGroup>
                                    {this.state.allSongsList.map((song, index) => (
                                         <ListGroupItem key={index}>
                                            <Button className="btn-video" onClick={( )=>this.handleSongChange(song)}>
                                                <p>{song.SongName}</p>
                                            </Button>
                                        </ListGroupItem>
                                    )
                                    )}
                                </ListGroup>
                           
                                
                            </Col>
                        </Row>
                    </Grid>

                </div>
                <Footer />
            </div>

        );
    }
}
export default Home;